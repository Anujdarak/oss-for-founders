"use client"

import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "cn"
import { motion } from "motion/react"
import { Tabs as TabsPrimitive } from "radix-ui"

import { SPRING } from "@/lib/motion"

/**
 * The active tab's value, so a trigger can tell whether it owns the indicator.
 *
 * Radix does not expose the selected value to triggers, and the indicator has
 * to be one shared element moving between them rather than one element per
 * trigger -- that shared identity is what lets Framer animate it across the
 * gap instead of cross-fading two separate boxes.
 */
const TabsValueContext = React.createContext<string | undefined>(undefined)
const TabsIdContext = React.createContext<string>("tabs")

function Tabs({
  className,
  orientation = "horizontal",
  value,
  defaultValue,
  onValueChange,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Root>) {
  // Mirrors Radix's own state so the indicator knows where to sit. When a
  // `value` prop is supplied the component stays controlled and this is only
  // a shadow copy.
  const [internal, setInternal] = React.useState<string | undefined>(
    value ?? defaultValue
  )
  const active = value ?? internal
  const instanceId = React.useId()

  const handleValueChange = React.useCallback(
    (next: string) => {
      setInternal(next)
      onValueChange?.(next)
    },
    [onValueChange]
  )
  return (
    <TabsIdContext.Provider value={instanceId}>
      <TabsValueContext.Provider value={active}>
        <TabsPrimitive.Root
          data-slot="tabs"
          value={value}
          defaultValue={defaultValue}
          onValueChange={handleValueChange}
          data-orientation={orientation}
          className={cn(
            "group/tabs flex gap-2 data-horizontal:flex-col",
            className
          )}
          {...props}
        />
      </TabsValueContext.Provider>
    </TabsIdContext.Provider>
  )
}

const tabsListVariants = cva(
  "group/tabs-list inline-flex w-fit items-center justify-center rounded-lg p-[3px] text-muted-foreground group-data-horizontal/tabs:h-8 group-data-vertical/tabs:h-fit group-data-vertical/tabs:flex-col data-[variant=line]:rounded-none",
  {
    variants: {
      variant: {
        default: "bg-muted",
        line: "gap-1 bg-transparent",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

function TabsList({
  className,
  variant = "default",
  ...props
}: React.ComponentProps<typeof TabsPrimitive.List> &
  VariantProps<typeof tabsListVariants>) {
  return (
    <TabsPrimitive.List
      data-slot="tabs-list"
      data-variant={variant}
      className={cn(tabsListVariants({ variant }), className)}
      {...props}
    />
  )
}

function TabsTrigger({
  className,
  children,
  value,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Trigger>) {
  const activeValue = React.useContext(TabsValueContext)
  const instanceId = React.useContext(TabsIdContext)
  const isActive = activeValue !== undefined && activeValue === value

  return (
    <TabsPrimitive.Trigger
      value={value}
      data-slot="tabs-trigger"
      className={cn(
        "relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-1.5 py-0.5 text-sm font-medium whitespace-nowrap text-foreground/60 transition-all group-data-vertical/tabs:w-full group-data-vertical/tabs:justify-start hover:text-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1 focus-visible:outline-ring disabled:pointer-events-none disabled:opacity-50 has-data-[icon=inline-end]:pr-1 has-data-[icon=inline-start]:pl-1 dark:text-muted-foreground dark:hover:text-foreground group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent",
        // The active background is painted by the shared motion element
        // below instead of by a data-active class, so it can travel between
        // triggers. Same tokens, same result when motion is reduced.
        "data-active:text-foreground dark:data-active:border-input dark:data-active:text-foreground",
        "after:absolute after:bg-foreground after:opacity-0 after:transition-opacity group-data-horizontal/tabs:after:inset-x-0 group-data-horizontal/tabs:after:bottom-[-5px] group-data-horizontal/tabs:after:h-0.5 group-data-vertical/tabs:after:inset-y-0 group-data-vertical/tabs:after:-right-1 group-data-vertical/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100",
        className
      )}
      {...props}
    >
      {isActive ? (
        <motion.span
          // One element shared across triggers: Framer sees the same layoutId
          // in a new position and animates it there, which is the slide.
          layoutId={`tabs-indicator-${instanceId}`}
          aria-hidden
          transition={SPRING}
          className="absolute inset-0 -z-10 rounded-md bg-background dark:bg-input/30"
        />
      ) : null}
      {children}
    </TabsPrimitive.Trigger>
  )
}

function TabsContent({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Content>) {
  return (
    <TabsPrimitive.Content
      data-slot="tabs-content"
      className={cn("flex-1 text-sm outline-none", className)}
      {...props}
    />
  )
}

export { Tabs, TabsList, TabsTrigger, TabsContent, tabsListVariants }
