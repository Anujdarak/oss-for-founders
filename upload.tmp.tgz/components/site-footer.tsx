import { CountUp } from "@/components/motion/count-up"
import { StatsDisclaimer } from "@/components/stats-disclaimer"
import { getAllRepos, getStatsUpdatedAt } from "@/lib/data"
import { SITE } from "@/lib/site"

export function SiteFooter() {
  const repos = getAllRepos()

  return (
    <footer className="mt-16 border-t border-border">
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-2 px-4 py-6 text-xs text-muted-foreground">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <p>{SITE.name}. Free and open source, no account required.</p>
          <p className="font-mono sm:ml-auto">
            <CountUp value={repos.length} />{" "}
            {repos.length === 1 ? "repository" : "repositories"}
          </p>
        </div>
        <StatsDisclaimer
          updatedAt={getStatsUpdatedAt()}
          className="max-w-prose border-t border-border pt-2"
        />
      </div>
    </footer>
  )
}
