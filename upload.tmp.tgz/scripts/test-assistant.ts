/**
 * Scores the assistant against tests/assistant-queries.json.
 *
 * Runs the retrieval engine directly rather than through the HTTP route, so
 * it measures the part that decides *which repos come back* without needing a
 * server or an API key. The LLM layers on top of this reorder and explain; if
 * retrieval is wrong, no amount of reranking saves the answer.
 *
 *   npm run test:assistant              summary plus failures
 *   npm run test:assistant -- --verbose every query
 *   npm run test:assistant -- --query "improve my ui ux"   one ad-hoc query
 */
import { readFileSync } from "node:fs"
import path from "node:path"

import { planLocally } from "../lib/assistant/plan"
import { retrieve } from "../lib/assistant/retrieve"

type Case = { q: string; expect: string[]; needs?: string[] }

const TOP_N = 3
/** A query passes when at least this many of the top N are in `expect`. */
const NEEDED = 2

const args = process.argv.slice(2)
const verbose = args.includes("--verbose")
const adhocIndex = args.indexOf("--query")
const adhoc = adhocIndex >= 0 ? args[adhocIndex + 1] : null

function topFor(query: string) {
  const plan = planLocally(query)
  const { candidates } = retrieve(plan)
  return { plan, candidates }
}

if (adhoc) {
  const { plan, candidates } = topFor(adhoc)
  console.log(`\nquery:  ${adhoc}`)
  console.log(`goal:   ${plan.goal}`)
  console.log(`needs:  ${plan.needs.map((n) => n.key).join(", ") || "(none)"}`)
  if (plan.needsClarification) console.log(`clarify: ${plan.clarifyingQuestion}`)
  console.log("")
  for (const [i, hit] of candidates.slice(0, 10).entries()) {
    console.log(
      `  ${String(i + 1).padStart(2)}. ${(hit.doc.owner + "/" + hit.doc.name).padEnd(34)} ` +
        `${hit.doc.category.padEnd(24)} need=${hit.needKey.padEnd(18)} ` +
        `score=${hit.score.toFixed(3)} cos=${hit.cosine.toFixed(3)} bm25=${hit.lexical.toFixed(2)}`
    )
  }
  process.exit(0)
}

const file = JSON.parse(
  readFileSync(path.join(process.cwd(), "tests", "assistant-queries.json"), "utf8")
) as { queries: Case[] }

const cases = file.queries
let passed = 0
const failures: string[] = []

const started = Date.now()

for (const testCase of cases) {
  const { plan, candidates } = topFor(testCase.q)
  const top = candidates.slice(0, TOP_N)
  const expected = new Set(testCase.expect)
  const hits = top.filter(
    (candidate) =>
      expected.has(candidate.doc.category) ||
      (candidate.doc.secondaryCategory && expected.has(candidate.doc.secondaryCategory))
  ).length

  const ok = hits >= NEEDED
  if (ok) passed += 1

  const line =
    `${ok ? "pass" : "FAIL"}  ${hits}/${TOP_N}  ${testCase.q}\n` +
    `        needs: ${plan.needs.map((n) => n.key).join(", ") || "(none)"}\n` +
    top
      .map(
        (candidate) =>
          `        - ${(candidate.doc.owner + "/" + candidate.doc.name).padEnd(32)} ` +
          `${candidate.doc.category}${expected.has(candidate.doc.category) ? "" : "  <- unexpected"}`
      )
      .join("\n")

  if (verbose) console.log(line)
  if (!ok) failures.push(line)
}

if (!verbose && failures.length > 0) {
  console.log("Failures\n========")
  for (const failure of failures) console.log(failure + "\n")
}

const rate = ((passed / cases.length) * 100).toFixed(1)
console.log(
  `\n${passed}/${cases.length} passed (${rate}%)  ` +
    `[top ${TOP_N}, need ${NEEDED} in expected categories]  ` +
    `${((Date.now() - started) / 1000).toFixed(1)}s`
)

// 54/60 is the agreed bar.
const THRESHOLD = Math.ceil(cases.length * 0.9)
if (passed < THRESHOLD) {
  console.error(`below threshold: needed ${THRESHOLD}/${cases.length}`)
  process.exit(1)
}
