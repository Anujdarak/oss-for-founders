/**
 * One interface over Gemini, Groq and OpenRouter.
 *
 * Server-only by construction: the key is read from `LLM_API_KEY`, which has
 * no `NEXT_PUBLIC_` prefix and therefore is never inlined into client code.
 * The guard below is belt and braces — if this module is ever imported from a
 * component that runs in the browser, it fails loudly instead of quietly
 * shipping a key.
 */
if (typeof window !== "undefined") {
  throw new Error("lib/assistant/llm is server-only and must never be imported by a client component")
}

export type Provider = "gemini" | "groq" | "openrouter"

export type LlmConfig = {
  provider: Provider
  apiKey: string
  model: string
}

/**
 * Default models, chosen by probing a real key rather than from memory.
 *
 * The first default here was `gemini-2.0-flash`, which the API now answers
 * with a 404: "no longer available". Model names age out, and the failure
 * mode is miserable — the request fails, the pipeline falls back, and the
 * answer still looks fine, so nothing tells you the key is doing nothing.
 *
 * Probe results against a free-tier key, November 2026:
 *   gemini-flash-lite-latest  1.2-3.1s, answered every time   <- chosen
 *   gemini-3.5-flash          4.3-5.1s when it worked, 503 about half the time
 *   gemini-3-flash-preview    2.4s once, then 503
 *   gemini-flash-latest       503 repeatedly, "high demand"
 *   gemini-3.8-flash          429, not on the free tier
 *   gemini-3.1-flash-lite     43s, far past any sane timeout
 *   gemini-2.5-flash          404, "no longer available to new users"
 *
 * Lite is the default on reliability, not speed. The bigger flash models
 * returned 503 often enough on a free-tier key that the assistant spent most
 * of its time timing out and falling back, and neither task here is hard
 * reasoning — decomposition into needs, then picking 3 of 40 candidates and
 * writing a sentence from supplied fields. Side by side on three real
 * questions the decompositions were comparable.
 *
 * Two traps worth naming. A pinned version ages out: the first default here
 * was `gemini-2.0-flash`, now a 404. And the `-latest` aliases are not the
 * safe answer they look like — `gemini-flash-latest` points at whatever is
 * newest, which is also whatever is most contended, and it 503'd every time.
 * `gemini-flash-lite-latest` is the alias to a tier nobody is stampeding.
 *
 * The Groq and OpenRouter defaults are unverified — I had no key for either.
 * If one of those 404s, set LLM_MODEL to a current name from the provider's
 * model list; the server log will say exactly what came back.
 */
const DEFAULT_MODELS: Record<Provider, string> = {
  gemini: "gemini-flash-lite-latest",
  groq: "llama-3.3-70b-versatile",
  openrouter: "google/gemini-2.0-flash-001",
}

/** Null when no key is configured, which is the signal to use the local engine. */
export function getLlmConfig(): LlmConfig | null {
  const apiKey = process.env.LLM_API_KEY?.trim()
  if (!apiKey) return null

  const raw = process.env.LLM_PROVIDER?.trim().toLowerCase()
  const provider: Provider =
    raw === "groq" || raw === "openrouter" || raw === "gemini" ? raw : "gemini"

  return {
    provider,
    apiKey,
    model: process.env.LLM_MODEL?.trim() || DEFAULT_MODELS[provider],
  }
}

export class LlmError extends Error {}

/**
 * 12s was too short. The probe that picked the model used a two-word prompt
 * and came back in 2.5s; the real `understand` prompt is a page of
 * instructions and the real rerank prompt carries 40 candidates, and the
 * first live run aborted on the timeout rather than on anything being wrong.
 *
 * Then back down to 12s once the default became the lite model, which answers
 * in 1-3s. The timeout is no longer there to wait out a slow answer — it is
 * there to give up on a congested model quickly and try the next one.
 */
const TIMEOUT_MS = 12_000

/**
 * Models to fall through to when the primary is busy, in order.
 *
 * A plain retry is the wrong move for a 503 that says "this model is
 * experiencing high demand" — the second attempt queues behind the same
 * congestion. Dropping to a different model answers the question instead.
 *
 * The chain runs lite-first and climbs: the default is the reliable one, and
 * these are the heavier models to try if even lite is busy. That is the
 * opposite of the usual arrangement, and it is what the measurements
 * supported on a free-tier key.
 */
const FALLBACK_MODELS: Record<Provider, string[]> = {
  gemini: ["gemini-3.5-flash", "gemini-3-flash-preview"],
  groq: [],
  openrouter: [],
}

/** Transient: worth another model or another go. */
function isRetryable(error: unknown): boolean {
  if (!(error instanceof LlmError)) return false
  return /\b(429|500|502|503|504)\b/.test(error.message)
}

/**
 * Ask for JSON and get a parsed object back, or throw.
 *
 * Every provider is asked for JSON mode where it exists, and the result is
 * still parsed defensively — JSON mode is a strong hint, not a guarantee, and
 * several models still wrap output in a ``` fence under load.
 */
export async function completeJson<T>(
  config: LlmConfig,
  system: string,
  user: string,
  signal?: AbortSignal
): Promise<T> {
  const models = [config.model, ...(FALLBACK_MODELS[config.provider] ?? [])]
  let lastError: unknown

  for (const model of models) {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS)
    if (signal) signal.addEventListener("abort", () => controller.abort(), { once: true })

    try {
      const text = await callProvider({ ...config, model }, system, user, controller.signal)
      return parseJson<T>(text)
    } catch (error) {
      lastError = error
      // A caller-cancelled request is not a provider problem: the reader
      // navigated away, and trying the next model wastes a call.
      if (signal?.aborted) throw error
      if (!isRetryable(error)) throw error
    } finally {
      clearTimeout(timeout)
    }
  }

  throw lastError instanceof Error ? lastError : new LlmError("every model failed")
}

async function callProvider(
  config: LlmConfig,
  system: string,
  user: string,
  signal: AbortSignal
): Promise<string> {
  if (config.provider === "gemini") {
    const url =
      `https://generativelanguage.googleapis.com/v1beta/models/` +
      `${encodeURIComponent(config.model)}:generateContent`
    const response = await fetch(url, {
      method: "POST",
      signal,
      headers: { "content-type": "application/json", "x-goog-api-key": config.apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: user }] }],
        generationConfig: { temperature: 0.2, responseMimeType: "application/json" },
      }),
    })
    if (!response.ok) throw new LlmError(`gemini ${response.status}: ${await safeText(response)}`)
    const payload = (await response.json()) as {
      candidates?: { content?: { parts?: { text?: string }[] } }[]
    }
    const text = payload.candidates?.[0]?.content?.parts?.map((part) => part.text ?? "").join("")
    if (!text) throw new LlmError("gemini returned no text")
    return text
  }

  // Groq and OpenRouter are both OpenAI-shaped.
  const endpoint =
    config.provider === "groq"
      ? "https://api.groq.com/openai/v1/chat/completions"
      : "https://openrouter.ai/api/v1/chat/completions"

  const response = await fetch(endpoint, {
    method: "POST",
    signal,
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${config.apiKey}`,
    },
    body: JSON.stringify({
      model: config.model,
      temperature: 0.2,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
  })
  if (!response.ok) {
    throw new LlmError(`${config.provider} ${response.status}: ${await safeText(response)}`)
  }
  const payload = (await response.json()) as {
    choices?: { message?: { content?: string } }[]
  }
  const text = payload.choices?.[0]?.message?.content
  if (!text) throw new LlmError(`${config.provider} returned no text`)
  return text
}

async function safeText(response: Response): Promise<string> {
  try {
    return (await response.text()).slice(0, 200)
  } catch {
    return "(no body)"
  }
}

/** Tolerates a ``` fence and leading prose around the object. */
export function parseJson<T>(text: string): T {
  const trimmed = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/```$/, "").trim()
  try {
    return JSON.parse(trimmed) as T
  } catch {
    const start = trimmed.indexOf("{")
    const end = trimmed.lastIndexOf("}")
    if (start >= 0 && end > start) {
      return JSON.parse(trimmed.slice(start, end + 1)) as T
    }
    throw new LlmError("response was not JSON")
  }
}
